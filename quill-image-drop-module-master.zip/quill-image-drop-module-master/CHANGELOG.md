# Changelog

## v1.0.3 - March 29, 2017

- Drop images at mouse coordinates instead of last caret position ([Issue #2](https://github.com/kensnyder/quill-image-drop-module/issues/2))

## v1.0.2 - March 25, 2017

- Add README link to plunker demo

## v1.0.1 - March 25, 2017

- Fix GitHub URL

## v1.0.0 - March 18, 2017

- Initial version