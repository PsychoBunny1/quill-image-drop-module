(function(){var exports={};
MINIFIED_JS
window.Quill.register('modules/imageDrop',exports.ImageDrop);})();